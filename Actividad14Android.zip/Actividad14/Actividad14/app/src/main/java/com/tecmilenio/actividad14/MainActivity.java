package com.tecmilenio.actividad14;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity{

    private SensorManager sensorManager;
    private TextView temperatureTextView;
    private TextView proximityTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        temperatureTextView = (TextView) findViewById(R.id.txt_temperature);
        proximityTextView = (TextView) findViewById(R.id.txt_proximity);

        // Creamos el administrador de sensores.
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);

        // Sensor temperatura.
        final Sensor temperatureSensor = sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE);

        if (temperatureSensor != null) {
            sensorManager.registerListener(new SensorEventListener() {
                @Override
                public void onSensorChanged(SensorEvent sensorEvent) {
                    if(sensorEvent.sensor.getType() == Sensor.TYPE_AMBIENT_TEMPERATURE)
                        if(sensorEvent.values != null)
                    temperatureTextView.setText("" + sensorEvent.values[0]);
                }

                @Override
                public void onAccuracyChanged(Sensor sensor, int i) {

                }
            }, temperatureSensor, SensorManager.SENSOR_DELAY_NORMAL);
        }

        // Sensor proximidad.
        Sensor proximitySensor = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);

        if (proximitySensor != null) {
            sensorManager.registerListener(new SensorEventListener() {
                @Override
                public void onSensorChanged(SensorEvent sensorEvent) {
                    if(sensorEvent.sensor.getType() == Sensor.TYPE_PROXIMITY) {
                        if(sensorEvent.values != null) {
                            if(sensorEvent.values[0] == 8.0) {
                                proximityTextView.setText("No hay un objeto cerca");
                            }else{
                                proximityTextView.setText("Hay un objeto cerca");
                            }
                        }
                    }
                }

                @Override
                public void onAccuracyChanged(Sensor sensor, int i) {

                }
            }, proximitySensor, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

}
