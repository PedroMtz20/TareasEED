package com.example.act8;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

//Pedro Elias Martinez Rodriguez 2777376
//Actividad 8

public class MainActivity extends AppCompatActivity {

    private static final int PERMISSION_PHONE_REQUEST_CODE = 102;

    //String que contendra el numero a llamar
    public String llamar = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Se inicializan las tablas y sus columnas
        TableLayout tabla = (TableLayout) findViewById(R.id.Tabla);
        tabla.setColumnStretchable(0,true);
        tabla.setColumnStretchable(1,true);
        TableRow row1 = (TableRow) findViewById(R.id.Row1);
        TableRow row2 = (TableRow) findViewById(R.id.Row2);
        TableRow row3 = (TableRow) findViewById(R.id.Row3);

        //Se van a crear 3 items, los cuales consisten de un nombre y un telefono
        TextView nombre1 = new TextView(this);
        TextView telefono1 = new TextView(this);
        TextView nombre2 = new TextView(this);
        TextView telefono2 = new TextView(this);
        TextView nombre3 = new TextView(this);
        TextView telefono3 = new TextView(this);

        //Se crea el item No1
        nombre1.setText("Pedro");
        nombre1.setTextSize(24);
        telefono1.setText("8116820723");
        telefono1.setTextSize(24);
        row1.addView(nombre1);
        row1.addView(telefono1);

        //Se crea el item No2
        nombre2.setText("Alejandro");
        nombre2.setTextSize(24);
        telefono2.setText("8114527621");
        telefono2.setTextSize(24);
        row2.addView(nombre2);
        row2.addView(telefono2);

        //Se crea el item No3
        nombre3.setText("Luis");
        nombre3.setTextSize(24);
        telefono3.setText("8175136488");
        telefono3.setTextSize(24);
        row3.addView(nombre3);
        row3.addView(telefono3);

        //Metodo para llamar el telefono 1
        telefono1.setOnClickListener(new View.OnClickListener(){
            @Override
                    public void onClick(View v){
                    llamar = ((TextView) v).getText().toString();
                    openPhone();
            }
        });

        //Metodo para llamar el telefono 2
        telefono2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                llamar = ((TextView) v).getText().toString();
                openPhone();
            }
        });

        //Metodo para llamar el telefono 3
        telefono3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                llamar = ((TextView) v).getText().toString();
                openPhone();
            }
        });
    }

    //Metodo que marca el telefono que se selecciono de los items
    private void openPhone() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            // La aplicación sí tiene permisos para realizar esta acción.
            Intent intent = new Intent(Intent.ACTION_CALL);
            intent.setData(Uri.parse("tel:" + llamar));
            startActivity(intent);
        } else {
            // La aplicación no tiene permisos para realizar esta acción y hay que solicitar el permiso al usuario.
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, PERMISSION_PHONE_REQUEST_CODE);
        }
    }

    //Resultado del permiso, si se dio el permiso no despleguera ningun mensaje
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case PERMISSION_PHONE_REQUEST_CODE:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    openPhone();
                } else {
                    Toast.makeText(this, "La aplicación no tiene acceso al teléfono", Toast.LENGTH_SHORT).show();
                }
                break;
            default:
                break;
        }
    }
}
