package com.example.act5;

//Pedro Elias Martinez Rodriguez 2777376
//Actividad 5 del curso de desarrollo de aplicaciones en plataforma Android
//Poder crear una aplicación que te dé el costo de algún producto con base en la definición de elementos éste



import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    //Se crea el metodo para el switch butto
    public void onSwitchButtonClicked(View view){
        //Se crean las instancias
        TextView Price = (TextView) findViewById(R.id.textView3);
        EditText CustomText = (EditText) findViewById(R.id.TextCustom);
        Switch boton = (Switch) findViewById(R.id.switch2);
        //Comprobacion para modificar el precio y hacer visible o invisible el texto
        if(boton.isChecked() == true){
            CustomText.setVisibility(View.VISIBLE);
            Price.setText("Total: $55 USD");
        }else{
            CustomText.setVisibility(View.INVISIBLE);
            Price.setText("Total: $40 USD");
        }

    }

    //Metoda para el boton de ordenar
    public void onButtonOrderCLicked(View view){
        //Se instancian todos los elementos
        TextView Title = (TextView) findViewById(R.id.Title);
        Button button = (Button) findViewById(R.id.button);
        EditText Name = (EditText) findViewById(R.id.editText2);
        TextView complete = (TextView) findViewById(R.id.Complete);
        TextView Price = (TextView) findViewById(R.id.textView3);
        TextView Color = (TextView) findViewById(R.id.textView2);
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        EditText CustomText = (EditText) findViewById(R.id.TextCustom);
        Switch boton = (Switch) findViewById(R.id.switch2);

        //Se sacan todos los elementos
        Title.setVisibility(View.GONE);
        button.setVisibility(View.GONE);
        Name.setVisibility(View.GONE);
        Price.setVisibility(View.GONE);
        Color.setVisibility(View.GONE);
        spinner.setVisibility(View.GONE);
        CustomText.setVisibility(View.GONE);
        boton.setVisibility(View.GONE);
        //Se despliega que la orden ha sido completada
        complete.setVisibility(View.VISIBLE);
    }

}
