package com.example.act4master.dummy;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Helper class for providing sample content for user interfaces created by
 * Android template wizards.
 * <p>
 * TODO: Replace all uses of this class before publishing your app.
 */
public class DummyContent {
    /**
     * An array of sample (dummy) items.
     */
    public static final List<DummyItem> ITEMS = new ArrayList<DummyItem>();

    /**
     * A map of sample (dummy) items, by ID.
     */
    public static final Map<String, DummyItem> ITEM_MAP = new HashMap<String, DummyItem>();

    //Se crean los DummyItems que pide la actividad
    static {
        addItem(new DummyItem("1", "Pedro", "8116820723"));
        addItem(new DummyItem("2","Alejandro","8114527621"));
        addItem(new DummyItem("3","Luis","https://www.amazon.com.mx/caba%C3%B1a-Paul-Young/dp/6070733126/ref=sr_1_20?qid=1567267423&s=books&smid=AVDBXBAVVSXLQ&sr=1-20"));
    }

    private static void addItem(DummyItem item) {
        ITEMS.add(item);
        ITEM_MAP.put(item.id, item);
    }

    private static DummyItem createDummyItem(int position) {
        return new DummyItem(String.valueOf(position), "Item " + position, makeDetails(position));
    }

    private static String makeDetails(int position) {
        StringBuilder builder = new StringBuilder();
        builder.append("Details about Item: ").append(position);
        for (int i = 0; i < position; i++) {
            builder.append("\nMore details information here.");
        }
        return builder.toString();
    }

    /**
     * A dummy item representing a piece of content.
     */
    public static class DummyItem {
        //Se cambia content a website_name y details a websiteUrl, simplemente para facilitar la lectura
        public final String id;
        public final String website_name;
        public final String websiteUrl;

        //Se asigna el dummyItem
        public DummyItem(String id, String content, String details) {
            this.id = id;
            this.website_name = content;
            this.websiteUrl= details;
        }

        @Override
        public String toString() {
            return website_name;
        }
    }
}
