package com.example.act6;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.transition.AutoTransition;
import android.transition.Scene;
import android.transition.Transition;
import android.transition.TransitionManager;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements DatePicker.OnDateChangedListener {

    //Pedro Elias Martinez Rodriguez 2777376
    //Actividad 6
    //Practicar en el uso de elementos de interfaz gráfica que no son tan básicos.

    //Se inicializan los calendarios
    private Calendar calendar = Calendar.getInstance();
    private Calendar actual = Calendar.getInstance();
    private boolean correcto = false;
    //Se inicializan las escenas
    private Scene scene1;
    private Transition transition;
    private boolean start;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Escena principal
        ViewGroup mSceneRoot = (ViewGroup) findViewById(R.id.scene_root);

        scene1 = Scene.getSceneForLayout(mSceneRoot, R.layout.first_scene,this);
        //Transiciones
        transition = new AutoTransition();
        transition.setDuration(1000);
        transition.setInterpolator(new AccelerateDecelerateInterpolator());

        start = true;

        //Se utiliza el codigo de la actividad y de Blacbloard para incializar y modificar los calendarios cuando se modifican los date y time picker
        TimePicker timePicker = (TimePicker) findViewById(R.id.timePicker);

        DatePicker datePicker = (DatePicker) findViewById(R.id.datePicker);
        datePicker.setOnDateChangedListener(this);

        timePicker.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker timePicker, int i, int i1) {
                int hour = i;
                int minute = i1;

                //Se comprueba que la cita sea cuando este abierto (8AM a 7 PM)
                if(hour > 8 && hour < 19) {
                    //Si esta dentro de ese horario se ajusta el calendario
                    Toast.makeText(MainActivity.this, i + " : " + i1, Toast.LENGTH_SHORT).show();
                    calendar.set(Calendar.HOUR_OF_DAY, hour);
                    calendar.set(Calendar.MINUTE, minute);
                    //Cita correcta
                    correcto = true;
                }else{
                    //La hora esta fuera de la hora abierta
                    Toast.makeText(MainActivity.this, "Estamos abiertos de 8AM a 7PM",Toast.LENGTH_SHORT).show();
                    //Cita invalida
                    correcto = false;
                }
            }
        });

    }

    //Metodo cuando el boton se clicke
    public void onButtonClick(View view){
        //Se le da un formato a la fecha de la cita para ser desplegada
        DateFormat dateFormat = SimpleDateFormat.getDateTimeInstance(DateFormat.DEFAULT,DateFormat.DEFAULT);
        String date = dateFormat.format(calendar.getTime());


        //Se comprueba que la fecha esta correcta y despliega el mensaje correspondiente
       if(correcto == true) {
            Toast.makeText(MainActivity.this, "Fecha de la cita: " + date, Toast.LENGTH_LONG).show();
           if(start){
               TransitionManager.go(scene1,transition);
               start = false;
               TextView fecha = (TextView) findViewById(R.id.FechaConfirmada);
               fecha.setText("Fecha de la cita: " +  date);
           }
        }else{
            Toast.makeText(MainActivity.this, "Fecha de cita incorrecta, revisa fecha y hora",Toast.LENGTH_SHORT).show();
            }
    }

    //Metodo para cuando se cambie la fecha, comprueba que la fecha no se pueda poner en el pasado
    @Override
    public void onDateChanged(DatePicker datePicker, int year, int month, int dayOfMonth) {

        //Si el year de la fecha es mayor que el actual entonces esta valido automaticamente
        if(datePicker.getYear() > actual.get(Calendar.YEAR)) {
            calendar.set(Calendar.YEAR, year);
            calendar.set(Calendar.MONTH, month);
            calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            correcto = true;

        }

        //Se tiene que comprobar que la fecha sea correcta en que caso de que el year sea el mismo, se va comprovando el mes y el dia si esto esta correcto
        if(datePicker.getYear() == actual.get(Calendar.YEAR)){
            if(datePicker.getMonth() > actual.get(Calendar.MONTH)){
                calendar.set(Calendar.YEAR, year);
                calendar.set(Calendar.MONTH, month);
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                correcto = true;
            }else if (datePicker.getMonth() == actual.get(Calendar.MONTH)){
                if(datePicker.getDayOfMonth() != actual.get(Calendar.DAY_OF_MONTH) && datePicker.getDayOfMonth() > actual.get(Calendar.DAY_OF_MONTH)){
                    calendar.set(Calendar.YEAR, year);
                    calendar.set(Calendar.MONTH, month);
                    calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                    correcto = true;
                }else{
                    Toast.makeText(MainActivity.this, "Fecha incorrecta ",Toast.LENGTH_SHORT).show();
                }
            }else{
                Toast.makeText(MainActivity.this, "Fecha incorrecta",Toast.LENGTH_SHORT).show();
            }
        }
    }

    }
