package com.tecmilenio.actividad11;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Definimos el texto para identificador.
    TextView txtId;

    // Definimos los campos de nombre,direccion,telefono,email.
    EditText editName;
    EditText editAddress;
    EditText editPhone;
    EditText editEmail;

    boolean phone;

    // Definimos el manejador de la base de datos.
    DBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtId = findViewById(R.id.txtId);
        editName = findViewById(R.id.editName);
        editAddress = findViewById(R.id.editAddress);
        editPhone = findViewById(R.id.editPhone);
        editEmail = findViewById(R.id.editEmail);

        dbHandler = new DBHandler(this, null, null, 1);
    }

    public void addClient(View view) {
        // Definimos las variables del cliente
        String name = editName.getText().toString().trim();
        String address = editAddress.getText().toString().trim();
        String phone = editPhone.getText().toString().trim();
        String email = editEmail.getText().toString().trim();

        // Creamos el object client.
        Client client = new Client(name, address, phone, email );

        // Agregamos el objeto a la base de datos.
        long result = dbHandler.addClient(client);

        if (result == -1) {
            txtId.setText(R.string.not_added);
        } else {
            txtId.setText(R.string.added);
        }

        editName.setText("");
        editAddress.setText("");
        editPhone.setText("");
        editEmail.setText("");
    }

    public void findClient(View view) {
        // Definimos el nombre.
        String name = editName.getText().toString().trim();

        //Vemos por que metodo se va a buscar (si por numero o por nombre)
        switch(view.getId()){
            case R.id.buttonName:
                phone = false;
                break;
            case R.id.buttonNumber:
                name = editPhone.getText().toString().trim();
                phone = true;
                break;
        }

        // Buscamos el Cliente.
        Client client = dbHandler.findClient(name,phone);

        // Verificamos si se encontró o no.
        if (client == null) {
            txtId.setText(R.string.not_found);
            editName.setText("");
            editAddress.setText("");
            editPhone.setText("");
            editEmail.setText("");
        } else {
            txtId.setText(String.valueOf(client.get_id()));
            editName.setText(client.get_name());
            editAddress.setText(String.valueOf(client.get_address()));
            editPhone.setText(String.valueOf(client.get_phone()));
            editEmail.setText(String.valueOf(client.get_email()));
        }
    }

    public void deleteClient(View view) {
        // Definimos el nombre.
        String name = editName.getText().toString().trim();

        // Verificamos si se borró el Cliente.
        if (dbHandler.deleteClient(name)) {
            txtId.setText(R.string.deleted);
        } else {
            txtId.setText(R.string.not_found);
        }

        editName.setText("");
        editAddress.setText("");
        editPhone.setText("");
        editEmail.setText("");
    }
}